#include "widget.h"
#include "ui_widget.h"
#include <QMultimedia>
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraImageCapture>
#include <QVBoxLayout>
#include <QMenu>
#include <QAction>
#include <QFileDialog>
#include<QPixmap>
#include <QLabel>
Widget::Widget(QWidget *parent)
    : QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    mCamera = new QCamera(this);
    mCameraViewfinder = new QCameraViewfinder(this);
    mCameraImageCapture =new QCameraImageCapture(mCamera,this);
    mLayout = new QVBoxLayout;
    mOpcionesMenu=new QMenu("Camera ",this);
    mCameraView=new QAction("Camera View",this);
    mCapturerImage =new QAction("captuierImage",this);
    mSaveImage=new QAction("Save Image",this);

    mOpcionesMenu->addActions({mCameraView,mCapturerImage,mSaveImage});
    ui->camera->setMenu(mOpcionesMenu);
    mCamera->setViewfinder(mCameraViewfinder);
    mLayout->addWidget(mCameraViewfinder);
    mLayout->setMargin(0);
    ui->scrollArea->setLayout(mLayout);

    connect(mCameraView,&QAction::triggered,[&](){mCamera->start();});
    connect(mCapturerImage,&QAction::triggered,[&](){mCamera->stop();});
    connect(mSaveImage,&QAction::triggered,[&](){
        auto filename= QFileDialog::getSaveFileName(this,"Capturar","/","/home/user/Pictures*.jpg;*.jpeg*.png)");
        if (filename.isEmpty()){
          return;
        }
        mCameraImageCapture->setCaptureDestination(QCameraImageCapture::CaptureToFile);
        QImageEncoderSettings ImageEncoderSettings;
        ImageEncoderSettings.setCodec("/home/user/image/jpeg");
        ImageEncoderSettings.setResolution(1600,1200);
        mCameraImageCapture->setEncodingSettings(ImageEncoderSettings);
        mCamera->setCaptureMode(QCamera::CaptureStillImage);
        mCamera->start();
        mCamera->searchAndLock();
        mCameraImageCapture->capture(filename);
        mCamera->unlock();
      });
}

Widget::~Widget()
{
    delete ui;
}



